function ExecuteScript(strId)
{
  switch (strId)
  {
      case "61wFW7XFvSt":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

